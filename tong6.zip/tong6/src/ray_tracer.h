#ifndef RAY_TRACER_H
#define RAY_TRACER_H

#include "embree.h"
#include <iostream>

struct depth_color {
	float depth;
	float color_r;
	float color_g;
	float color_b;
} ;



class ray_tracer
{
	public:
		static int samples;

	public:
		ray_tracer() = default;
		~ray_tracer() = default;

		virtual depth_color intersect_depth(const glm::vec3 & org, const glm::vec3 & dir) = 0;

		void raycasting(float* buffer, const glm::ivec2& window_size, const Camera& cam);
		virtual void shadow_rays(float* buffer, const glm::ivec2& window_size, const Camera& cam, glm::vec3 lightbox_position) = 0;



		glm::vec3 ray_view_dir(const glm::ivec2 & pos, const glm::ivec2 & window_size, const glm::mat4 & inv_proj_view, const glm::vec3 & cam_pos);
};


// TODO: this ray tracer implementation compute the ray triangle intersection with all the triangles in the scene.
class rt_simple: public ray_tracer
{
	// TODO: add possible data members and class methods.
	public:

		rt_simple(const std::vector<Shape*>& shapes) : all_shapes(shapes) {}
		~rt_simple() = default;
		// TODO: complete the definition of this method.
		depth_color intersect_depth(const glm::vec3 & org, const glm::vec3 & dir);
		void shadow_rays(float* buffer, const glm::ivec2& window_size, const Camera& cam, glm::vec3 lightbox_position);


		std::vector<Shape*> all_shapes;

};



class rt_embree: public ray_tracer, public embree
{
	public:

		rt_embree(const std::vector<Shape *> & shapes)
		{
			for(auto & mesh: shapes)
				add_mesh(*mesh);

			build_bvh();
		}
		void shadow_rays(float* buffer, const glm::ivec2& window_size, const Camera& cam, glm::vec3 lightbox_position);
		depth_color intersect_depth(const glm::vec3 & org, const glm::vec3 & dir)
		{
			depth_color d_c;
			ray_hit r(org, dir);
			d_c.depth = intersect(r) ? r.ray.tfar : 0.f;
			d_c.color_r = 0;
			d_c.color_g = 0;
			d_c.color_b = 0;

			if (d_c.depth) {
				return d_c;
			}
			else {


				//purpose of this part:assign color to the pixels we have found that are not under shadows
				//sorry I can not solve this part thus I assign specific color to pixels explictly rather than giving the correct color
				d_c.color_r = 0.5;
				d_c.color_g = 0.5;
				d_c.color_b = 0.5;

















				return d_c;
			}
		}
};

#endif // RAY_TRACER_H

