#include "ray_tracer.h"
#include <glm/gtc/random.hpp>
#include <iostream>

// TODO: play with the samples number, add a input control in the UI (user interface, ImGui window)
int ray_tracer::samples = 1;


void ray_tracer::raycasting(float * buffer, const glm::ivec2 & window_size, const Camera & cam)
{
	glm::mat4 inv_proj_view = glm::inverse(cam.getViewProjectionMatrix());

	#pragma omp parallel for
	for(int i = 0; i < window_size.x; ++i)
	for(int j = 0; j < window_size.y; ++j)
	{
		//row major
		float & depth = buffer[(window_size.y - j - 1) * window_size.x + i] = 0;
		glm::vec3 dir = ray_view_dir({i, j}, window_size, inv_proj_view, cam.getPosition());

		for(int s = 0; s < samples; ++s)
			depth += intersect_depth(cam.getPosition(), dir).depth;

		depth /= samples;
	}
}











void rt_embree::shadow_rays(float* buffer, const glm::ivec2& window_size, const Camera& cam, glm::vec3 lightbox_position)
{
	glm::mat4 inv_proj_view = glm::inverse(cam.getViewProjectionMatrix());

	#pragma omp parallel for
	for (int i = 0; i < window_size.x; ++i)
		for (int j = 0; j < window_size.y; ++j)
		{
			//row major

			float& color_r = buffer[(window_size.y - j - 1) * window_size.x + i] = 0;
			float& color_g = buffer[window_size.x * window_size.y + (window_size.y - j - 1) * window_size.x + i] = 0;
			float& color_b = buffer[2 * (window_size.x * window_size.y) + (window_size.y - j - 1) * window_size.x + i] = 0;

			glm::vec3 dir = ray_view_dir({ i, j }, window_size, inv_proj_view, cam.getPosition());
			ray_hit r(cam.getPosition(), dir);
			float depth = intersect(r) ? r.ray.tfar : 0;

			if (depth != 0) {

				//in fact, for each light here, however, only one light in this scene
				glm::vec3 now_point = cam.getPosition() + dir * depth;

				glm::vec3 light_dir = glm::normalize(lightbox_position - now_point);


				depth_color d_c;
				d_c = intersect_depth(now_point, light_dir);
				if (d_c.depth == 0) {
					color_r = d_c.color_r;
					color_g = d_c.color_g;
					color_b = d_c.color_b;

				}
			}
		}
}

void rt_simple::shadow_rays(float* buffer, const glm::ivec2& window_size, const Camera& cam, glm::vec3 lightbox_position)
{
	glm::mat4 inv_proj_view = glm::inverse(cam.getViewProjectionMatrix());

	#pragma omp parallel for
	for (int i = 0; i < window_size.x; ++i)
		for (int j = 0; j < window_size.y; ++j)
		{
			//row major
			float& color_r = buffer[(window_size.y - j - 1) * window_size.x + i] = 0;
			float& color_g = buffer[window_size.x * window_size.y + (window_size.y - j - 1) * window_size.x + i] = 0;
			float& color_b = buffer[2 * (window_size.x * window_size.y) + (window_size.y - j - 1) * window_size.x + i] = 0;

			glm::vec3 dir = ray_view_dir({ i, j }, window_size, inv_proj_view, cam.getPosition());
			float depth = intersect_depth(cam.getPosition(), dir).depth;

			if (depth != 0) {

				//in fact, for each light here, however, only one light in this scene
				glm::vec3 now_point = cam.getPosition() + dir * depth;

				glm::vec3 light_dir = glm::normalize(lightbox_position - now_point);


				depth_color d_c;
				d_c = intersect_depth(now_point, light_dir);
				float point_to_occlusion_distance = d_c.depth;


				if (point_to_occlusion_distance == 0) {
					color_r = d_c.color_r;
					color_g = d_c.color_g;
					color_b = d_c.color_b;
				}

			}



		}
}



























glm::vec3 ray_tracer::ray_view_dir(const glm::ivec2 & pos, const glm::ivec2 & window_size, const glm::mat4 & inv_proj_view, const glm::vec3 & cam_pos)
{
	glm::vec2 normalized_device_coordinates((2.0f * pos.x) / window_size.x - 1.0f, (2.0f * pos.y) / window_size.y - 1.0f);
	glm::vec4 point_on_viewport = inv_proj_view * glm::vec4(normalized_device_coordinates.x, normalized_device_coordinates.y, -1.0f, 1.0f);
	glm::vec3 world_space(point_on_viewport.x / point_on_viewport.w, point_on_viewport.y / point_on_viewport.w, point_on_viewport.z / point_on_viewport.w);
	float rand_factor = 0.0001;
	glm::vec3 random_offset = {static_cast<float>(rand()) / RAND_MAX * rand_factor,static_cast<float>(rand()) / RAND_MAX * rand_factor,static_cast<float>(rand()) / RAND_MAX * rand_factor};
	glm::vec3 ray_view_dir = glm::normalize(world_space - cam_pos + random_offset);
	return ray_view_dir;

}

// TODO: add the definition of the methods here.














depth_color rt_simple::intersect_depth(const glm::vec3& org, const glm::vec3& dir)
{

	depth_color d_c;
	d_c.depth = 99999;
	d_c.color_r = 0;
	d_c.color_g = 0;
	d_c.color_b = 0;

	for(int j=0;j<all_shapes.size();j++){

		Shape* s=all_shapes[j];

		const glm::mat4& model_matrix = s->getModelMatrix();

		std::vector<glm::vec3> all_positions = s->positions;
		std::vector<glm::uvec3> all_faces = s->faces;
		std::vector<glm::vec3> all_colors = s->colors;


		std::vector<glm::vec3> transformed_positions;

		for (const auto& pos : all_positions) {
			glm::vec4 transformed_pos = model_matrix * glm::vec4(pos, 1.0f);
			transformed_positions.push_back(glm::vec3(transformed_pos));
		}


		all_positions = transformed_positions;








		//purpose of this part:assign color to the pixels we have found that are not under shadows
		//sorry I can not solve this part thus I assign specific color to pixels explictly rather than giving the correct color
		//we could find color in the process of determining whether the pixel is under shadow
		d_c.color_r = 0.5;
		d_c.color_g = 0.5;
		d_c.color_b = 0.5;





		for (int i = 0; i < all_faces.size(); i++) {
			glm::uvec3 f = all_faces[i];
			glm::vec3 point1 = all_positions[f.x];
			glm::vec3 point2 = all_positions[f.y];
			glm::vec3 point3 = all_positions[f.z];


			glm::vec3 N = glm::normalize(glm::cross(point1 - point2, point2 - point3));


			float N_dot_ray_direction = glm::dot(N,dir);
			if (fabs(N_dot_ray_direction) > 0.0001) {
				float D = -glm::dot(N, point1);
				glm::vec3 edge1 = point2 - point1;
				glm::vec3 edge2 = point3 - point2;
				glm::vec3 edge3 = point1 - point3;


				float t = -(glm::dot(N, org) + D) / glm::dot(N, dir);
				if (t > 0.0001) {
					glm::vec3 p = org + t * dir;


					glm::vec3 c1 = p - point1;
					glm::vec3 c2 = p - point2;
					glm::vec3 c3 = p - point3;

					if (glm::dot(N, glm::cross(edge1, c1)) > 0 && glm::dot(N, glm::cross(edge2, c2)) > 0 && glm::dot(N, glm::cross(edge3, c3)) > 0) {
						if (t < d_c.depth) {
							d_c.depth = t;
						}

					}
				}
			}
		}

	}


	if (d_c.depth == 99999) {
		d_c.depth = 0;
		//should color here, but we could color in the former loop
		//we could find color in the process of determining whether the pixel is under shadow

	}



	return d_c;
}
